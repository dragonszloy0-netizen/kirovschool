package ru.kirov.schoolmod

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    const val BLUE = 0xFF2566D2.toInt()
    const val DARK_BLUE = 0xFF084482.toInt()
    const val BG = 0xFFF7F7F7.toInt()
    const val RED = 0xFFB33A3A.toInt()
    const val LIGHT = 0xFFE4ECF7.toInt()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.header(title: String): TextView = TextView(this).apply {
    text = title; setTextColor(Color.WHITE); textSize = 22f
    setTypeface(typeface, android.graphics.Typeface.BOLD)
    setBackgroundColor(C.BLUE); gravity = Gravity.CENTER_VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

fun Context.roundBg(color: Int, radius: Int = 12, stroke: Int? = null) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(radius).toFloat()
    if (stroke != null) setStroke(dp(2), stroke)
}

fun Context.button(text: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
    this.text = text; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
    background = roundBg(bg, 10); setPadding(dp(12), dp(12), dp(12), dp(12))
    setOnClickListener { onClick() }
}

fun Context.spacer(h: Int) = View(this).apply {
    layoutParams = LinearLayout.LayoutParams(1, dp(h))
}
