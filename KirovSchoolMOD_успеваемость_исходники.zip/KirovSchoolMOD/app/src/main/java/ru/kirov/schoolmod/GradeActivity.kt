package ru.kirov.schoolmod

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Локальный журнал оценок. Данные хранятся отдельно от расписания в SharedPreferences. */
class GradeActivity : Activity() {
    private data class Grade(val id: Long, val subject: String, val mark: Int, val date: String)

    private val prefsName = "personal_grades"
    private val grades = mutableListOf<Grade>()
    private lateinit var list: LinearLayout
    private lateinit var subjectSpinner: Spinner
    private lateinit var average: TextView
    private var subjects = listOf("Все предметы")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadGrades()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
        }
        root.addView(header("Моя успеваемость"), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        subjectSpinner = Spinner(this)
        controls.addView(subjectSpinner, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        average = TextView(this).apply {
            textSize = 18f
            setTextColor(C.DARK_BLUE)
            setPadding(0, dp(10), 0, dp(10))
        }
        controls.addView(average)
        controls.addView(button("+ Добавить оценку", C.BLUE) { chooseSubjectForGrade() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(controls)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(16))
        }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
        refreshSubjects()
        subjectSpinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                render()
            }
        })
    }

    private fun availableSubjects(): List<String> = ScheduleStore.load(this)
        .flatten().map { it.subject.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    private fun refreshSubjects() {
        val selected = subjectSpinner.selectedItem?.toString()
        subjects = listOf("Все предметы") + (availableSubjects() + grades.map { it.subject }).distinct().sorted()
        subjectSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, subjects)
        val index = subjects.indexOf(selected).takeIf { it >= 0 } ?: 0
        subjectSpinner.setSelection(index, false)
        render()
    }

    private fun chooseSubjectForGrade() {
        val options = (availableSubjects() + grades.map { it.subject }).distinct().sorted().toMutableList()
        options.add("Другой предмет…")
        if (options.isEmpty()) options.add("Другой предмет…")
        AlertDialog.Builder(this).setTitle("Выберите предмет")
            .setItems(options.toTypedArray()) { _, which ->
                if (options[which] == "Другой предмет…") askCustomSubject()
                else chooseMark(options[which])
            }.show()
    }

    private fun askCustomSubject() {
        val input = android.widget.EditText(this).apply { hint = "Название предмета" }
        AlertDialog.Builder(this).setTitle("Новый предмет").setView(input)
            .setPositiveButton("Далее") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) chooseMark(name)
                else Toast.makeText(this, "Введите название предмета", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun chooseMark(subject: String) {
        AlertDialog.Builder(this).setTitle("Оценка по предмету: $subject")
            .setItems(arrayOf("2", "3", "4", "5")) { _, which ->
                val mark = which + 2
                grades.add(Grade(System.currentTimeMillis(), subject, mark, java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date())))
                saveGrades()
                refreshSubjects()
                Toast.makeText(this, "Оценка $mark сохранена", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun render() {
        if (!::list.isInitialized || !::average.isInitialized) return
        val selected = subjectSpinner.selectedItem?.toString() ?: "Все предметы"
        val shown = grades.filter { selected == "Все предметы" || it.subject == selected }.sortedByDescending { it.id }
        average.text = if (shown.isEmpty()) "Средний балл: —" else
            "Средний балл: ${"%.2f".format(java.util.Locale.getDefault(), shown.map { it.mark }.average())}  •  Оценок: ${shown.size}"
        list.removeAllViews()
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Оценок пока нет"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(0xFF777777.toInt())
                setPadding(0, dp(36), 0, 0)
            })
            return
        }
        shown.forEach { grade ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundBg(android.graphics.Color.WHITE, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = grade.subject
                textSize = 17f
                setTextColor(android.graphics.Color.BLACK)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            info.addView(TextView(this).apply {
                text = grade.date
                textSize = 13f
                setTextColor(0xFF777777.toInt())
            })
            card.addView(info, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            card.addView(TextView(this).apply {
                text = grade.mark.toString()
                textSize = 24f
                setTextColor(C.BLUE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(12), 0, dp(12), 0)
            })
            card.addView(TextView(this).apply {
                text = "Удалить"
                textSize = 13f
                setTextColor(C.RED)
                setOnClickListener {
                    AlertDialog.Builder(this@GradeActivity).setMessage("Удалить оценку?")
                        .setPositiveButton("Удалить") { _, _ -> grades.removeAll { it.id == grade.id }; saveGrades(); render() }
                        .setNegativeButton("Отмена", null).show()
                }
            })
            list.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            })
        }
    }

    private fun loadGrades() {
        val raw = getSharedPreferences(prefsName, MODE_PRIVATE).getString("grades", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val mark = item.optInt("mark", 0)
                val subject = item.optString("subject").trim()
                if (mark in 2..5 && subject.isNotEmpty()) grades.add(
                    Grade(item.optLong("id", i.toLong()), subject, mark, item.optString("date"))
                )
            }
        } catch (_: Exception) { grades.clear() }
    }

    private fun saveGrades() {
        val array = JSONArray()
        grades.forEach { array.put(JSONObject().put("id", it.id).put("subject", it.subject).put("mark", it.mark).put("date", it.date)) }
        getSharedPreferences(prefsName, MODE_PRIVATE).edit().putString("grades", array.toString()).apply()
    }
}
