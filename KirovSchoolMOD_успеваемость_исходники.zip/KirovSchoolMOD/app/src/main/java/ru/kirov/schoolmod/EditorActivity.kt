package ru.kirov.schoolmod

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class EditorActivity : Activity() {
    private val dayNames = listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")
    private lateinit var data: MutableList<MutableList<Lesson>>
    private var day = 0

    private class Row(val l: Lesson, val subj: EditText, val room: EditText,
                      val teacher: EditText, val start: EditText, val end: EditText)
    private val rows = mutableListOf<Row>()

    private lateinit var tabs: LinearLayout
    private lateinit var list: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        data = ScheduleStore.load(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        root.addView(header("Редактор расписания"), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        tabs = LinearLayout(this).apply { weightSum = 7f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        root.addView(tabs, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(12)) }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.WHITE) }
        bar.addView(button("+ Добавить урок", C.BLUE) {
            collect(); data[day].add(Lesson("", "", "", "", "")); render()
        })
        bar.addView(spacer(8))
        val two = LinearLayout(this).apply { weightSum = 2f }
        two.addView(button("Сохранить", 0xFF2E8B57.toInt()) {
            collect(); ScheduleStore.save(this, data)
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { rightMargin = dp(4) })
        two.addView(button("Вернуть оригинал", C.RED) {
            AlertDialog.Builder(this).setTitle("Вернуть оригинальное расписание?")
                .setMessage("Все ваши изменения будут удалены.")
                .setPositiveButton("Да") { _, _ ->
                    ScheduleStore.reset(this); data = ScheduleStore.load(this); render()
                    Toast.makeText(this, "Расписание сброшено", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("Отмена", null).show()
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(4) })
        bar.addView(two)
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(root)
        render()
    }

    private fun collect() {
        for (r in rows) {
            r.l.subject = r.subj.text.toString(); r.l.room = r.room.text.toString()
            r.l.teacher = r.teacher.text.toString(); r.l.start = r.start.text.toString()
            r.l.end = r.end.text.toString()
        }
    }

    private fun field(hint: String, value: String, w: Float = 1f) = EditText(this).apply {
        setHint(hint); setText(value); textSize = 15f; inputType = InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, w)
    }

    private fun render() {
        tabs.removeAllViews()
        for (i in 0 until 7) {
            tabs.addView(TextView(this).apply {
                text = dayNames[i]; gravity = Gravity.CENTER; textSize = 15f
                setPadding(0, dp(10), 0, dp(10))
                setTextColor(if (i == day) Color.WHITE else Color.BLACK)
                background = roundBg(if (i == day) C.BLUE else Color.WHITE, 8)
                setOnClickListener { collect(); day = i; render() }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }

        list.removeAllViews(); rows.clear()
        data[day].forEachIndexed { idx, l ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                background = roundBg(Color.WHITE, 12); setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(TextView(this).apply { text = "Урок ${idx + 1}"; textSize = 16f
                setTextColor(C.BLUE) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            head.addView(TextView(this).apply { text = "Удалить"; setTextColor(C.RED); textSize = 14f
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { collect(); data[day].remove(l); render() } })
            card.addView(head)
            val subj = field("Предмет", l.subject, 1f)
            val teacher = field("Учитель", l.teacher, 1f)
            val room = field("Кабинет", l.room, 1f)
            val start = field("Начало 08:30", l.start, 1f)
            val end = field("Конец 09:15", l.end, 1f)
            card.addView(LinearLayout(this).apply { addView(subj) })
            card.addView(LinearLayout(this).apply { addView(teacher) })
            card.addView(LinearLayout(this).apply { addView(room); addView(start); addView(end) })
            rows.add(Row(l, subj, room, teacher, start, end))
            list.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(10)) })
        }
    }

    override fun onBackPressed() { collect(); super.onBackPressed() }
}
