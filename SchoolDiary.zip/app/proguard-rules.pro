# Минификация отключена (isMinifyEnabled = false), правила не требуются.
