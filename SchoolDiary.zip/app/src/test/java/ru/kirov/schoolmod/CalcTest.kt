package ru.kirov.schoolmod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import ru.kirov.schoolmod.data.Bells
import ru.kirov.schoolmod.data.Calc
import org.junit.Test
import java.time.LocalDate

class CalcTest {

    @Test
    fun averageAndFormat() {
        assertEquals(3.75, Calc.average(listOf(3, 4, 5, 3))!!, 1e-9)
        assertNull(Calc.average(emptyList()))
        assertEquals("3.75", Calc.format(3.75))
        assertEquals("4.5", Calc.format(4.5))
        assertEquals("4", Calc.format(4.0))
        assertEquals("3.67", Calc.format(11.0 / 3.0))
    }

    @Test
    fun quarters() {
        assertEquals(1, Calc.quarterOf(LocalDate.of(2026, 9, 15)))
        assertEquals(2, Calc.quarterOf(LocalDate.of(2026, 11, 16)))
        assertEquals(3, Calc.quarterOf(LocalDate.of(2027, 2, 1)))
        assertEquals(4, Calc.quarterOf(LocalDate.of(2027, 5, 10)))
    }

    @Test
    fun timeParsing() {
        assertEquals(510, Bells.parse("08:30"))
        assertEquals(510, Bells.parse("8:30"))
        assertNull(Bells.parse("24:00"))
        assertNull(Bells.parse("08:60"))
        assertNull(Bells.parse("abc"))
        assertEquals("08:30", Bells.format(510))
    }
}
