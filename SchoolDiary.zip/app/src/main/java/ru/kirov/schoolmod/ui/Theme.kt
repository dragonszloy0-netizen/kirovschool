package ru.kirov.schoolmod.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Brand = Color(0xFF1E5BD3)

private val LightColors = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FB),
    onPrimaryContainer = Color(0xFF0B2A66),
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF14161C),
    surface = Color.White,
    onSurface = Color(0xFF14161C),
    surfaceVariant = Color(0xFFE9ECF3),
    onSurfaceVariant = Color(0xFF5A6070),
    outline = Color(0xFFC3C8D4),
    error = Color(0xFFD32F2F)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FB2FF),
    onPrimary = Color(0xFF0B2A66),
    primaryContainer = Color(0xFF1B3F8F),
    onPrimaryContainer = Color(0xFFDCE6FB),
    background = Color(0xFF101217),
    onBackground = Color(0xFFE6E8EE),
    surface = Color(0xFF1A1D24),
    onSurface = Color(0xFFE6E8EE),
    surfaceVariant = Color(0xFF2A2E38),
    onSurfaceVariant = Color(0xFFA9AFBD),
    outline = Color(0xFF454B59),
    error = Color(0xFFEF9A9A)
)

@Composable
fun DiaryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

/** Цвет оценки или среднего балла: 5 — зелёный, 4 — салатовый, 3 — жёлтый, 2 — оранжевый, 1 — красный. */
fun gradeColor(v: Double): Color = when {
    v >= 4.75 -> Color(0xFF5DB82E)
    v >= 3.5 -> Color(0xFF8CC63F)
    v >= 2.5 -> Color(0xFFF5B800)
    v >= 1.5 -> Color(0xFFF57C00)
    else -> Color(0xFFE53935)
}
