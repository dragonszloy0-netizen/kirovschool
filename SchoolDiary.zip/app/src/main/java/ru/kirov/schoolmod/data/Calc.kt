package ru.kirov.schoolmod.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.util.Locale

object Calc {
    fun average(values: List<Int>): Double? =
        if (values.isEmpty()) null else values.sum().toDouble() / values.size

    /** 3.75 -> "3.75", 4.5 -> "4.5", 4.0 -> "4". */
    fun format(avg: Double): String =
        BigDecimal.valueOf(avg).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

    /** Четверть по дате: сен–окт = 1, ноя–дек = 2, янв–мар = 3, остальное = 4. */
    fun quarterOf(date: LocalDate): Int = when (date.monthValue) {
        9, 10 -> 1
        11, 12 -> 2
        1, 2, 3 -> 3
        else -> 4
    }
}

object Fmt {
    fun shortDate(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return String.format(Locale.ROOT, "%02d.%02d", d.dayOfMonth, d.monthValue)
    }

    fun fullDate(date: LocalDate): String =
        String.format(Locale.ROOT, "%02d.%02d.%d", date.dayOfMonth, date.monthValue, date.year)
}
