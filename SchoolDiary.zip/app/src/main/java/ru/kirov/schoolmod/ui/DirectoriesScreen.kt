@file:OptIn(ExperimentalMaterial3Api::class)

package ru.kirov.schoolmod.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.kirov.schoolmod.DiaryViewModel
import ru.kirov.schoolmod.data.DiaryData

private class Entry(val id: Long, val name: String, val usage: String)

private data class NameEdit(val kind: Int, val id: Long?, val name: String)

private data class DeleteReq(val kind: Int, val id: Long, val name: String, val message: String)

private val kindTitles = listOf("Предметы", "Учителя", "Кабинеты")
private val newTitles = listOf("Новый предмет", "Новый учитель", "Новый кабинет")
private val editTitles = listOf("Изменить предмет", "Изменить учителя", "Изменить кабинет")
private val fieldLabels = listOf("Название предмета", "ФИО учителя", "Номер или название кабинета")
private val emptyTexts = listOf("Предметов пока нет", "Учителей пока нет", "Кабинетов пока нет")

private fun entriesOf(data: DiaryData, kind: Int): List<Entry> {
    val list = when (kind) {
        0 -> data.subjects.map { s ->
            val lessons = data.lessons.count { it.subjectId == s.id }
            val grades = data.grades.count { it.subjectId == s.id }
            Entry(s.id, s.name, "Уроков: $lessons  •  Оценок: $grades")
        }
        1 -> data.teachers.map { t ->
            Entry(t.id, t.name, "Уроков: ${data.lessons.count { it.teacherId == t.id }}")
        }
        else -> data.rooms.map { r ->
            Entry(r.id, r.name, "Уроков: ${data.lessons.count { it.roomId == r.id }}")
        }
    }
    return list.sortedBy { it.name.lowercase() }
}

/** Справочники: предметы, учителя, кабинеты. Добавление, переименование, удаление. */
@Composable
fun DirectoriesScreen(data: DiaryData, vm: DiaryViewModel) {
    val context = LocalContext.current
    var kind by rememberSaveable { mutableIntStateOf(0) }
    var editor by remember { mutableStateOf<NameEdit?>(null) }
    var deleting by remember { mutableStateOf<DeleteReq?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    val entries = entriesOf(data, kind)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                kindTitles.forEachIndexed { i, title ->
                    PillTab(
                        text = title,
                        selected = kind == i,
                        onClick = { kind = i },
                        modifier = Modifier.weight(1f),
                        horizontalPadding = 4.dp
                    )
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (entries.isEmpty()) {
                    item {
                        Text(
                            emptyTexts[kind] + ". Нажмите «Добавить».",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
                items(entries, key = { it.id }) { e ->
                    EntryCard(
                        entry = e,
                        onEdit = { editor = NameEdit(kind, e.id, e.name) },
                        onDelete = {
                            deleting = DeleteReq(kind, e.id, e.name, deleteMessage(data, kind, e))
                        }
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { confirmReset = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) { Text("Вернуть оригинальное расписание") }
                }
            }
        }

        ExtendedFloatingActionButton(
            text = { Text("Добавить") },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            onClick = { editor = NameEdit(kind, null, "") },
            containerColor = Brand,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )
    }

    editor?.let { e ->
        val taken = entriesOf(data, e.kind)
        NameDialog(
            title = if (e.id == null) newTitles[e.kind] else editTitles[e.kind],
            label = fieldLabels[e.kind],
            initial = e.name,
            isTaken = { name -> taken.any { it.name.equals(name, ignoreCase = true) && it.id != e.id } },
            onSave = { name ->
                val ok = when (e.kind) {
                    0 -> vm.saveSubject(e.id, name)
                    1 -> vm.saveTeacher(e.id, name)
                    else -> vm.saveRoom(e.id, name)
                }
                if (ok) editor = null
            },
            onDismiss = { editor = null }
        )
    }

    deleting?.let { d ->
        ConfirmDialog(
            title = "Удалить «${d.name}»?",
            text = d.message,
            confirmLabel = "Удалить",
            onConfirm = {
                when (d.kind) {
                    0 -> vm.deleteSubject(d.id)
                    1 -> vm.deleteTeacher(d.id)
                    else -> vm.deleteRoom(d.id)
                }
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Вернуть оригинальное расписание?",
            text = "Все ваши изменения в расписании будут удалены. " +
                "Предметы, учителя и оценки останутся.",
            confirmLabel = "Да",
            onConfirm = {
                vm.resetSchedule()
                confirmReset = false
                Toast.makeText(context, "Расписание сброшено", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { confirmReset = false }
        )
    }
}

private fun deleteMessage(data: DiaryData, kind: Int, e: Entry): String = when (kind) {
    0 -> {
        val lessons = data.lessons.count { it.subjectId == e.id }
        val grades = data.grades.count { it.subjectId == e.id }
        "Вместе с предметом будут удалены его уроки в расписании ($lessons) и оценки ($grades)."
    }
    1 -> "Учитель будет убран из уроков: ${data.lessons.count { it.teacherId == e.id }}."
    else -> "Кабинет будет убран из уроков: ${data.lessons.count { it.roomId == e.id }}."
}

@Composable
private fun EntryCard(entry: Entry, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                Modifier
                    .weight(1f)
                    .clickable(onClick = onEdit)
                    .padding(vertical = 8.dp)
            ) {
                Text(entry.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    entry.usage,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Изменить")
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Удалить",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
