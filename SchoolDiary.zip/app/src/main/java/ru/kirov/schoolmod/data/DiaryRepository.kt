package ru.kirov.schoolmod.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Хранит все данные в одном файле filesDir/diary.json.
 * Каждое изменение сразу записывается на диск (во временный файл с последующей
 * заменой), поэтому данные не теряются после перезапуска или закрытия приложения.
 */
class DiaryRepository(context: Context) {

    private val file = File(context.applicationContext.filesDir, "diary.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writeLock = Mutex()

    private val _data = MutableStateFlow(load())
    val data: StateFlow<DiaryData> = _data.asStateFlow()

    init {
        if (!file.exists()) save()
    }

    fun update(block: (DiaryData) -> DiaryData) {
        _data.update(block)
        save()
    }

    private fun save() {
        scope.launch {
            writeLock.withLock {
                // Всегда пишем самое свежее состояние: подряд идущие правки не теряются.
                write(_data.value)
            }
        }
    }

    private fun load(): DiaryData {
        return try {
            if (file.exists()) DiaryJson.decode(file.readText(Charsets.UTF_8)) else Seed.initial()
        } catch (e: Exception) {
            Log.e(TAG, "Не удалось прочитать diary.json, создаю новые данные", e)
            runCatching { file.copyTo(File(file.parentFile, "diary.corrupt.json"), overwrite = true) }
            Seed.initial()
        }
    }

    private fun write(d: DiaryData) {
        try {
            val tmp = File(file.parentFile, "diary.json.tmp")
            FileOutputStream(tmp).use { out ->
                out.write(DiaryJson.encode(d).toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            try {
                Files.move(
                    tmp.toPath(), file.toPath(),
                    StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE
                )
            } catch (e: Exception) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка записи diary.json", e)
        }
    }

    private companion object {
        const val TAG = "DiaryRepository"
    }
}
