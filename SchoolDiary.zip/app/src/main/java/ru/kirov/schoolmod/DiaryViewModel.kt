package ru.kirov.schoolmod

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow
import ru.kirov.schoolmod.data.Bells
import ru.kirov.schoolmod.data.DiaryData
import ru.kirov.schoolmod.data.DiaryRepository
import ru.kirov.schoolmod.data.FinalGrade
import ru.kirov.schoolmod.data.Grade
import ru.kirov.schoolmod.data.Lesson
import ru.kirov.schoolmod.data.Room
import ru.kirov.schoolmod.data.Seed
import ru.kirov.schoolmod.data.Subject
import ru.kirov.schoolmod.data.Teacher

class DiaryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = DiaryRepository(app)
    val data: StateFlow<DiaryData> = repo.data

    // ---------- Предметы ----------

    /** id == null — новый предмет. Возвращает false, если имя пустое или уже занято. */
    fun saveSubject(id: Long?, rawName: String): Boolean {
        val name = rawName.trim()
        if (name.isEmpty()) return false
        if (data.value.subjects.any { it.name.equals(name, ignoreCase = true) && it.id != id }) return false
        repo.update { d ->
            if (id == null) {
                d.copy(subjects = d.subjects + Subject(d.nextId, name), nextId = d.nextId + 1)
            } else {
                d.copy(subjects = d.subjects.map { if (it.id == id) it.copy(name = name) else it })
            }
        }
        return true
    }

    /** Вместе с предметом удаляются его уроки и оценки. */
    fun deleteSubject(id: Long) = repo.update { d ->
        d.copy(
            subjects = d.subjects.filterNot { it.id == id },
            lessons = d.lessons.filterNot { it.subjectId == id },
            grades = d.grades.filterNot { it.subjectId == id },
            finals = d.finals.filterNot { it.subjectId == id }
        )
    }

    // ---------- Учителя ----------

    fun saveTeacher(id: Long?, rawName: String): Boolean {
        val name = rawName.trim()
        if (name.isEmpty()) return false
        if (data.value.teachers.any { it.name.equals(name, ignoreCase = true) && it.id != id }) return false
        repo.update { d ->
            if (id == null) {
                d.copy(teachers = d.teachers + Teacher(d.nextId, name), nextId = d.nextId + 1)
            } else {
                d.copy(teachers = d.teachers.map { if (it.id == id) it.copy(name = name) else it })
            }
        }
        return true
    }

    /** Из уроков учитель просто убирается. */
    fun deleteTeacher(id: Long) = repo.update { d ->
        d.copy(
            teachers = d.teachers.filterNot { it.id == id },
            lessons = d.lessons.map { if (it.teacherId == id) it.copy(teacherId = null) else it }
        )
    }

    // ---------- Кабинеты ----------

    fun saveRoom(id: Long?, rawName: String): Boolean {
        val name = rawName.trim()
        if (name.isEmpty()) return false
        if (data.value.rooms.any { it.name.equals(name, ignoreCase = true) && it.id != id }) return false
        repo.update { d ->
            if (id == null) {
                d.copy(rooms = d.rooms + Room(d.nextId, name), nextId = d.nextId + 1)
            } else {
                d.copy(rooms = d.rooms.map { if (it.id == id) it.copy(name = name) else it })
            }
        }
        return true
    }

    fun deleteRoom(id: Long) = repo.update { d ->
        d.copy(
            rooms = d.rooms.filterNot { it.id == id },
            lessons = d.lessons.map { if (it.roomId == id) it.copy(roomId = null) else it }
        )
    }

    // ---------- Уроки ----------

    /** lesson.id == 0 — новый урок. Возвращает текст ошибки или null, если сохранено. */
    fun saveLesson(lesson: Lesson): String? {
        val startMin = Bells.parse(lesson.start)
        val endMin = Bells.parse(lesson.end)
        if (startMin == null || endMin == null) return "Время вводится как ЧЧ:ММ, например 08:30"
        if (endMin <= startMin) return "Конец урока должен быть позже начала"

        val cur = data.value
        if (cur.subjects.none { it.id == lesson.subjectId }) return "Выберите предмет"
        if (cur.lessons.any { it.day == lesson.day && it.number == lesson.number && it.id != lesson.id }) {
            return "В этот день урок №${lesson.number} уже есть"
        }

        val normalized = lesson.copy(start = Bells.format(startMin), end = Bells.format(endMin))
        repo.update { d ->
            if (normalized.id == 0L) {
                d.copy(
                    lessons = d.lessons + normalized.copy(id = d.nextId),
                    nextId = d.nextId + 1
                )
            } else {
                d.copy(lessons = d.lessons.map { if (it.id == normalized.id) normalized else it })
            }
        }
        return null
    }

    fun deleteLesson(id: Long) = repo.update { d ->
        d.copy(lessons = d.lessons.filterNot { it.id == id })
    }

    /** «Вернуть оригинал»: расписание заменяется исходным. */
    fun resetSchedule() = repo.update { d -> Seed.resetSchedule(d) }

    // ---------- Оценки ----------

    /** grade.id == 0 — новая оценка. */
    fun saveGrade(grade: Grade) {
        if (grade.value !in 1..5 || grade.quarter !in 1..4) return
        repo.update { d ->
            if (grade.id == 0L) {
                d.copy(
                    grades = d.grades + grade.copy(id = d.nextId),
                    nextId = d.nextId + 1
                )
            } else {
                d.copy(grades = d.grades.map { if (it.id == grade.id) grade else it })
            }
        }
    }

    fun deleteGrade(id: Long) = repo.update { d ->
        d.copy(grades = d.grades.filterNot { it.id == id })
    }

    /** value == null — убрать итоговую оценку. period: 1..4 четверти, 5 год. */
    fun setFinal(subjectId: Long, period: Int, value: Int?) {
        if (period !in 1..5) return
        if (value != null && value !in 1..5) return
        repo.update { d ->
            val rest = d.finals.filterNot { it.subjectId == subjectId && it.period == period }
            d.copy(finals = if (value == null) rest else rest + FinalGrade(subjectId, period, value))
        }
    }
}
