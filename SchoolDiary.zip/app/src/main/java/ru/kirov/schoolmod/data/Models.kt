package ru.kirov.schoolmod.data

import java.util.Locale

data class Subject(val id: Long, val name: String)

data class Teacher(val id: Long, val name: String)

data class Room(val id: Long, val name: String)

/** day: 1 = ПН ... 6 = СБ. teacherId / roomId могут быть не указаны. */
data class Lesson(
    val id: Long,
    val day: Int,
    val number: Int,
    val subjectId: Long,
    val teacherId: Long?,
    val roomId: Long?,
    val start: String,
    val end: String
)

/** Текущая оценка. quarter: 1..4. */
data class Grade(
    val id: Long,
    val subjectId: Long,
    val epochDay: Long,
    val value: Int,
    val quarter: Int
)

/** Итоговая оценка. period: 1..4 — четверти, 5 — год. */
data class FinalGrade(val subjectId: Long, val period: Int, val value: Int)

data class DiaryData(
    val subjects: List<Subject> = emptyList(),
    val teachers: List<Teacher> = emptyList(),
    val rooms: List<Room> = emptyList(),
    val lessons: List<Lesson> = emptyList(),
    val grades: List<Grade> = emptyList(),
    val finals: List<FinalGrade> = emptyList(),
    val nextId: Long = 1L
) {
    fun subjectName(id: Long): String = subjects.firstOrNull { it.id == id }?.name ?: "—"
    fun teacherName(id: Long?): String? = teachers.firstOrNull { it.id == id }?.name
    fun roomName(id: Long?): String? = rooms.firstOrNull { it.id == id }?.name
}

object Days {
    val short = listOf("ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ")
    val full = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота")
}

/** Стандартное расписание звонков и разбор времени «ЧЧ:ММ». */
object Bells {
    const val MAX_LESSONS = 10

    private val table = listOf(
        "08:30" to "09:15",
        "09:25" to "10:10",
        "10:30" to "11:15",
        "11:25" to "12:10",
        "12:20" to "13:05",
        "13:15" to "14:00",
        "14:10" to "14:55",
        "15:05" to "15:50",
        "16:00" to "16:45",
        "16:55" to "17:40"
    )

    private val timeRegex = Regex("^([01]?\\d|2[0-3]):([0-5]\\d)$")

    fun start(number: Int): String = table.getOrNull(number - 1)?.first ?: "08:30"

    fun end(number: Int): String = table.getOrNull(number - 1)?.second ?: "09:15"

    /** Возвращает минуты от начала суток или null, если формат неверный. */
    fun parse(text: String): Int? {
        val m = timeRegex.matchEntire(text.trim()) ?: return null
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }

    fun format(minutes: Int): String =
        String.format(Locale.ROOT, "%02d:%02d", minutes / 60, minutes % 60)
}
