@file:OptIn(ExperimentalMaterial3Api::class)

package ru.kirov.schoolmod.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.kirov.schoolmod.DiaryViewModel
import ru.kirov.schoolmod.data.Calc
import ru.kirov.schoolmod.data.DiaryData
import ru.kirov.schoolmod.data.Fmt
import ru.kirov.schoolmod.data.Grade
import ru.kirov.schoolmod.data.Subject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private data class GradeEdit(val subject: Subject, val grade: Grade?)

private data class FinalEdit(val subject: Subject, val period: Int)

private val quarterNames =
    listOf("Первая четверть", "Вторая четверть", "Третья четверть", "Четвёртая четверть")
private val periodNames = listOf("1 четверть", "2 четверть", "3 четверть", "4 четверть", "Год")
private val periodShort = listOf("1 четв.", "2 четв.", "3 четв.", "4 четв.", "Год")

/** Экран «Успеваемость»: «Текущая» (оценки по датам) и «Итоговая» (четверти и год). */
@Composable
fun GradesScreen(data: DiaryData, vm: DiaryViewModel) {
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var quarter by rememberSaveable { mutableIntStateOf(Calc.quarterOf(LocalDate.now())) }
    var gradeEdit by remember { mutableStateOf<GradeEdit?>(null) }
    var finalEdit by remember { mutableStateOf<FinalEdit?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            PillTab("Текущая", mode == 0, { mode = 0 })
            Spacer(Modifier.width(16.dp))
            PillTab("Итоговая", mode == 1, { mode = 1 })
        }

        if (data.subjects.isEmpty()) {
            EmptyHint("Нет предметов", "Добавьте предметы во вкладке «Справочники».")
        } else if (mode == 0) {
            CurrentGrades(data, quarter, { quarter = it }, { gradeEdit = it })
        } else {
            FinalGrades(data) { finalEdit = it }
        }
    }

    gradeEdit?.let { e ->
        GradeDialog(
            subjectName = e.subject.name,
            initial = e.grade,
            defaultQuarter = quarter,
            onSave = { epochDay, value, q ->
                vm.saveGrade(Grade(e.grade?.id ?: 0L, e.subject.id, epochDay, value, q))
                quarter = q
                gradeEdit = null
            },
            onDelete = e.grade?.let { g ->
                {
                    vm.deleteGrade(g.id)
                    gradeEdit = null
                }
            },
            onDismiss = { gradeEdit = null }
        )
    }

    finalEdit?.let { e ->
        val current = data.finals
            .firstOrNull { it.subjectId == e.subject.id && it.period == e.period }?.value
        AlertDialog(
            onDismissRequest = { finalEdit = null },
            title = { Text("Итоговая оценка") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("${e.subject.name} — ${periodNames[e.period - 1]}", fontSize = 16.sp)
                    GradeValueRow(current) { v ->
                        vm.setFinal(e.subject.id, e.period, v)
                        finalEdit = null
                    }
                }
            },
            confirmButton = {
                Row {
                    if (current != null) {
                        TextButton(onClick = {
                            vm.setFinal(e.subject.id, e.period, null)
                            finalEdit = null
                        }) { Text("Очистить") }
                    }
                    TextButton(onClick = { finalEdit = null }) { Text("Отмена") }
                }
            }
        )
    }
}

@Composable
private fun CurrentGrades(
    data: DiaryData,
    quarter: Int,
    onQuarter: (Int) -> Unit,
    onEdit: (GradeEdit) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quarterNames.forEachIndexed { i, name ->
                PillTab(name, quarter == i + 1, { onQuarter(i + 1) })
            }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            items(data.subjects, key = { it.id }) { subject ->
                val grades = data.grades
                    .filter { it.subjectId == subject.id && it.quarter == quarter }
                    .sortedWith(compareBy<Grade>({ it.epochDay }, { it.id }))
                SubjectGrades(subject, grades, onEdit)
            }
        }
    }
}

@Composable
private fun SubjectGrades(subject: Subject, grades: List<Grade>, onEdit: (GradeEdit) -> Unit) {
    val avg = Calc.average(grades.map { it.value })
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 22.dp)
    ) {
        Text(subject.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        LazyRow(
            Modifier.padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(grades, key = { it.id }) { g ->
                GradeTile(g) { onEdit(GradeEdit(subject, g)) }
            }
            item {
                AddTile { onEdit(GradeEdit(subject, null)) }
            }
        }
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Средний балл:", fontSize = 18.sp)
            Spacer(Modifier.width(10.dp))
            Text(
                text = if (avg == null) "—" else Calc.format(avg),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (avg == null) MaterialTheme.colorScheme.onSurfaceVariant else gradeColor(avg)
            )
        }
    }
}

@Composable
private fun GradeTile(g: Grade, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier.size(width = 76.dp, height = 84.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(Fmt.shortDate(g.epochDay), fontSize = 17.sp)
            Text(
                text = g.value.toString(),
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = gradeColor(g.value.toDouble())
            )
        }
    }
}

@Composable
private fun AddTile(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.size(width = 76.dp, height = 84.dp)
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Filled.Add,
                contentDescription = "Добавить оценку",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@Composable
private fun FinalGrades(data: DiaryData, onEdit: (FinalEdit) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        items(data.subjects, key = { it.id }) { subject ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(subject.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        for (p in 1..5) {
                            val finalValue = data.finals
                                .firstOrNull { it.subjectId == subject.id && it.period == p }?.value
                            val values = data.grades
                                .filter { it.subjectId == subject.id && (p == 5 || it.quarter == p) }
                                .map { it.value }
                            FinalCell(
                                period = p,
                                finalValue = finalValue,
                                avg = Calc.average(values),
                                modifier = Modifier.weight(1f),
                                onClick = { onEdit(FinalEdit(subject, p)) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FinalCell(
    period: Int,
    finalValue: Int?,
    avg: Double?,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            periodShort[period - 1],
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = finalValue?.toString() ?: "—",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = if (finalValue != null) gradeColor(finalValue.toDouble())
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (avg != null) "ср. ${Calc.format(avg)}" else " ",
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun GradeDialog(
    subjectName: String,
    initial: Grade?,
    defaultQuarter: Int,
    onSave: (epochDay: Long, value: Int, quarter: Int) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var date by remember {
        mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.epochDay) } ?: LocalDate.now())
    }
    var value by remember { mutableStateOf(initial?.value) }
    var quarter by remember { mutableIntStateOf(initial?.quarter ?: defaultQuarter) }
    var quarterTouched by remember { mutableStateOf(initial != null) }
    var showPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новая оценка" else "Оценка") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(subjectName, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                OutlinedButton(
                    onClick = { showPicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Дата: ${Fmt.fullDate(date)}") }
                GradeValueRow(value) { value = it }
                PickerField(
                    label = "Четверть",
                    valueText = quarterNames[quarter - 1],
                    options = quarterNames.mapIndexed { i, n -> (i + 1).toLong() to n },
                    onSelect = { k ->
                        if (k != null) {
                            quarter = k.toInt()
                            quarterTouched = true
                        }
                    }
                )
            }
        },
        confirmButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Удалить", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
                TextButton(
                    enabled = value != null,
                    onClick = { value?.let { onSave(date.toEpochDay(), it, quarter) } }
                ) { Text("Сохранить") }
            }
        }
    )

    if (showPicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        date = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        if (!quarterTouched) quarter = Calc.quarterOf(date)
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Отмена") } }
        ) {
            DatePicker(state = state)
        }
    }
}
