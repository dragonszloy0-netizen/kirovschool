@file:OptIn(ExperimentalMaterial3Api::class)

package ru.kirov.schoolmod.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.kirov.schoolmod.data.Calc
import ru.kirov.schoolmod.data.DiaryData
import ru.kirov.schoolmod.data.Days
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Главная: сегодняшние уроки (или ближайший учебный день) и краткая статистика. */
@Composable
fun HomeScreen(data: DiaryData, onOpenSchedule: () -> Unit, onOpenGrades: () -> Unit) {
    val today = LocalDate.now()
    val dow = today.dayOfWeek.value // 1 = ПН ... 7 = ВС
    val hasToday = dow in 1..6 && data.lessons.any { it.day == dow }

    val shownDay: Int? = if (hasToday) {
        dow
    } else {
        (1..7)
            .map { (dow - 1 + it) % 7 + 1 }
            .firstOrNull { d -> d in 1..6 && data.lessons.any { it.day == d } }
    }
    val shownLessons = if (shownDay == null) {
        emptyList()
    } else {
        data.lessons.filter { it.day == shownDay }.sortedBy { it.number }
    }

    val dateText = today
        .format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.forLanguageTag("ru")))
        .replaceFirstChar { it.uppercase() }
    val overall = Calc.average(data.grades.map { it.value })

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Brand,
                contentColor = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(dateText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = when {
                            hasToday -> "Сегодня уроков: ${shownLessons.size}"
                            else -> "Сегодня уроков нет"
                        },
                        fontSize = 16.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(data.subjects.size.toString(), "предметов", Modifier.weight(1f))
                StatTile(data.lessons.size.toString(), "уроков в неделю", Modifier.weight(1f))
                StatTile(
                    value = if (overall == null) "—" else Calc.format(overall),
                    label = "средний балл",
                    modifier = Modifier.weight(1f),
                    valueColor = overall?.let { gradeColor(it) }
                )
            }
        }

        item {
            Text(
                text = when {
                    shownDay == null -> "Расписание"
                    hasToday -> "Уроки на сегодня"
                    else -> "Ближайший учебный день: ${Days.full[shownDay - 1]}"
                },
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (shownLessons.isEmpty()) {
            item {
                Text(
                    "Расписание пока пустое. Добавьте уроки во вкладке «Расписание».",
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(shownLessons, key = { it.id }) { l -> LessonCard(data, l) }
        }

        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(onClick = onOpenSchedule, modifier = Modifier.weight(1f)) {
                    Text("Расписание")
                }
                OutlinedButton(onClick = onOpenGrades, modifier = Modifier.weight(1f)) {
                    Text("Успеваемость")
                }
            }
        }
    }
}

@Composable
private fun StatTile(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    valueColor: Color? = null
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = modifier
    ) {
        Column(
            Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor ?: MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
