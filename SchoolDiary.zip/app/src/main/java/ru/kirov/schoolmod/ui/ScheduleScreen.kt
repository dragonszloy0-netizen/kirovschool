@file:OptIn(ExperimentalMaterial3Api::class)

package ru.kirov.schoolmod.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.kirov.schoolmod.DiaryViewModel
import ru.kirov.schoolmod.data.Bells
import ru.kirov.schoolmod.data.DiaryData
import ru.kirov.schoolmod.data.Days
import ru.kirov.schoolmod.data.Lesson
import java.time.LocalDate

private data class LessonEdit(val lesson: Lesson?)

private fun initialDay(): Int {
    val d = LocalDate.now().dayOfWeek.value
    return if (d in 1..6) d else 1
}

/** Расписание по дням недели: добавление, изменение и удаление уроков. */
@Composable
fun ScheduleScreen(data: DiaryData, vm: DiaryViewModel) {
    var day by rememberSaveable { mutableIntStateOf(initialDay()) }
    var editing by remember { mutableStateOf<LessonEdit?>(null) }
    var deleting by remember { mutableStateOf<Lesson?>(null) }
    val lessons = data.lessons.filter { it.day == day }.sortedBy { it.number }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Days.short.forEachIndexed { i, name ->
                    DayChip(name, day == i + 1, Modifier.weight(1f)) { day = i + 1 }
                }
            }

            if (lessons.isEmpty()) {
                EmptyHint(
                    "Нет уроков",
                    "Нажмите «Добавить урок», чтобы заполнить ${Days.full[day - 1].lowercase()}."
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(lessons, key = { it.id }) { l ->
                        LessonCard(data, l) { editing = LessonEdit(l) }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            text = { Text("Добавить урок") },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            onClick = { editing = LessonEdit(null) },
            containerColor = Brand,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )
    }

    editing?.let { e ->
        LessonDialog(
            data = data,
            defaultDay = day,
            initial = e.lesson,
            onSave = { l ->
                val err = vm.saveLesson(l)
                if (err == null) day = l.day
                err
            },
            onDelete = e.lesson?.let { l ->
                {
                    deleting = l
                    editing = null
                }
            },
            onDismiss = { editing = null }
        )
    }

    deleting?.let { l ->
        ConfirmDialog(
            title = "Удалить урок?",
            text = "${data.subjectName(l.subjectId)} (${Days.full[l.day - 1]}, урок ${l.number}) " +
                "будет удалён из расписания.",
            confirmLabel = "Удалить",
            onConfirm = {
                vm.deleteLesson(l.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}

@Composable
private fun DayChip(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Brand else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) Color.White else MaterialTheme.colorScheme.primary
    ) {
        Box(Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Text(text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

/** Карточка урока; используется на главной и в расписании. */
@Composable
fun LessonCard(data: DiaryData, lesson: Lesson, onClick: (() -> Unit)? = null) {
    val details = listOfNotNull(
        data.teacherName(lesson.teacherId),
        data.roomName(lesson.roomId)?.let { "каб. $it" }
    ).joinToString("  •  ")

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lesson.number.toString(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    data.subjectName(lesson.subjectId),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (details.isNotEmpty()) {
                    Text(
                        details,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                "${lesson.start}–${lesson.end}",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun firstFreeNumber(data: DiaryData, day: Int): Int =
    (1..Bells.MAX_LESSONS).firstOrNull { n ->
        data.lessons.none { it.day == day && it.number == n }
    } ?: Bells.MAX_LESSONS

/** Диалог добавления и изменения урока. onSave возвращает текст ошибки или null. */
@Composable
fun LessonDialog(
    data: DiaryData,
    defaultDay: Int,
    initial: Lesson?,
    onSave: (Lesson) -> String?,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var day by remember { mutableIntStateOf(initial?.day ?: defaultDay) }
    var number by remember {
        mutableIntStateOf(initial?.number ?: firstFreeNumber(data, defaultDay))
    }
    var subjectId by remember { mutableStateOf(initial?.subjectId) }
    var teacherId by remember { mutableStateOf(initial?.teacherId) }
    var roomId by remember { mutableStateOf(initial?.roomId) }
    var start by remember { mutableStateOf(initial?.start ?: Bells.start(number)) }
    var end by remember { mutableStateOf(initial?.end ?: Bells.end(number)) }
    var error by remember { mutableStateOf<String?>(null) }

    val notSet = "Не указан"
    val teacherOptions: List<Pair<Long?, String>> =
        listOf<Pair<Long?, String>>(null to notSet) + data.teachers.map { it.id to it.name }
    val roomOptions: List<Pair<Long?, String>> =
        listOf<Pair<Long?, String>>(null to notSet) + data.rooms.map { it.id to it.name }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый урок" else "Изменить урок") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PickerField(
                    label = "День",
                    valueText = Days.full[day - 1],
                    options = Days.full.mapIndexed { i, n -> (i + 1).toLong() to n },
                    onSelect = { k -> if (k != null) day = k.toInt() }
                )
                PickerField(
                    label = "Номер урока",
                    valueText = number.toString(),
                    options = (1..Bells.MAX_LESSONS).map { it.toLong() to it.toString() },
                    onSelect = { k ->
                        if (k != null) {
                            number = k.toInt()
                            start = Bells.start(number)
                            end = Bells.end(number)
                        }
                    }
                )
                if (data.subjects.isEmpty()) {
                    Text(
                        "Сначала добавьте предметы во вкладке «Справочники».",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 14.sp
                    )
                } else {
                    PickerField(
                        label = "Предмет",
                        valueText = data.subjects.firstOrNull { it.id == subjectId }?.name
                            ?: "Выберите предмет",
                        options = data.subjects.map { it.id to it.name },
                        onSelect = { k -> subjectId = k }
                    )
                }
                PickerField(
                    label = "Учитель",
                    valueText = data.teacherName(teacherId) ?: notSet,
                    options = teacherOptions,
                    onSelect = { k -> teacherId = k }
                )
                PickerField(
                    label = "Кабинет",
                    valueText = data.roomName(roomId) ?: notSet,
                    options = roomOptions,
                    onSelect = { k -> roomId = k }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text("Начало") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        label = { Text("Конец") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Удалить", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
                TextButton(onClick = {
                    val sid = subjectId
                    val err = if (sid == null) {
                        "Выберите предмет"
                    } else {
                        onSave(
                            Lesson(
                                id = initial?.id ?: 0L,
                                day = day,
                                number = number,
                                subjectId = sid,
                                teacherId = teacherId,
                                roomId = roomId,
                                start = start.trim(),
                                end = end.trim()
                            )
                        )
                    }
                    if (err == null) onDismiss() else error = err
                }) { Text("Сохранить") }
            }
        }
    )
}
