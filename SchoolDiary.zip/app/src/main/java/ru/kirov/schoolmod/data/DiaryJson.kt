package ru.kirov.schoolmod.data

import org.json.JSONArray
import org.json.JSONObject

/** Сериализация всех данных дневника в один JSON-файл. */
object DiaryJson {

    private const val VERSION = 1

    fun encode(d: DiaryData): String {
        val root = JSONObject()
        root.put("version", VERSION)
        root.put("nextId", d.nextId)

        val subjects = JSONArray()
        d.subjects.forEach { subjects.put(JSONObject().put("id", it.id).put("name", it.name)) }
        root.put("subjects", subjects)

        val teachers = JSONArray()
        d.teachers.forEach { teachers.put(JSONObject().put("id", it.id).put("name", it.name)) }
        root.put("teachers", teachers)

        val rooms = JSONArray()
        d.rooms.forEach { rooms.put(JSONObject().put("id", it.id).put("name", it.name)) }
        root.put("rooms", rooms)

        val lessons = JSONArray()
        d.lessons.forEach { l ->
            val o = JSONObject()
            o.put("id", l.id)
            o.put("day", l.day)
            o.put("number", l.number)
            o.put("subjectId", l.subjectId)
            val t = l.teacherId
            if (t != null) o.put("teacherId", t)
            val r = l.roomId
            if (r != null) o.put("roomId", r)
            o.put("start", l.start)
            o.put("end", l.end)
            lessons.put(o)
        }
        root.put("lessons", lessons)

        val grades = JSONArray()
        d.grades.forEach { g ->
            grades.put(
                JSONObject()
                    .put("id", g.id)
                    .put("subjectId", g.subjectId)
                    .put("epochDay", g.epochDay)
                    .put("value", g.value)
                    .put("quarter", g.quarter)
            )
        }
        root.put("grades", grades)

        val finals = JSONArray()
        d.finals.forEach { f ->
            finals.put(
                JSONObject()
                    .put("subjectId", f.subjectId)
                    .put("period", f.period)
                    .put("value", f.value)
            )
        }
        root.put("finals", finals)

        return root.toString()
    }

    fun decode(text: String): DiaryData {
        val root = JSONObject(text)

        val subjects = root.optJSONArray("subjects").objects()
            .map { Subject(it.getLong("id"), it.getString("name")) }
        val teachers = root.optJSONArray("teachers").objects()
            .map { Teacher(it.getLong("id"), it.getString("name")) }
        val rooms = root.optJSONArray("rooms").objects()
            .map { Room(it.getLong("id"), it.getString("name")) }
        val lessons = root.optJSONArray("lessons").objects().map {
            Lesson(
                id = it.getLong("id"),
                day = it.getInt("day"),
                number = it.getInt("number"),
                subjectId = it.getLong("subjectId"),
                teacherId = if (it.has("teacherId")) it.getLong("teacherId") else null,
                roomId = if (it.has("roomId")) it.getLong("roomId") else null,
                start = it.getString("start"),
                end = it.getString("end")
            )
        }
        val grades = root.optJSONArray("grades").objects().map {
            Grade(
                id = it.getLong("id"),
                subjectId = it.getLong("subjectId"),
                epochDay = it.getLong("epochDay"),
                value = it.getInt("value"),
                quarter = it.getInt("quarter")
            )
        }
        val finals = root.optJSONArray("finals").objects().map {
            FinalGrade(it.getLong("subjectId"), it.getInt("period"), it.getInt("value"))
        }

        // nextId никогда не должен быть меньше уже использованных идентификаторов.
        val maxId = maxOf(
            subjects.maxOfOrNull { it.id } ?: 0L,
            teachers.maxOfOrNull { it.id } ?: 0L,
            rooms.maxOfOrNull { it.id } ?: 0L,
            lessons.maxOfOrNull { it.id } ?: 0L,
            grades.maxOfOrNull { it.id } ?: 0L
        )
        val nextId = maxOf(root.optLong("nextId", 1L), maxId + 1)

        return DiaryData(subjects, teachers, rooms, lessons, grades, finals, nextId)
    }

    private fun JSONArray?.objects(): List<JSONObject> {
        if (this == null) return emptyList()
        return (0 until length()).map { getJSONObject(it) }
    }
}
