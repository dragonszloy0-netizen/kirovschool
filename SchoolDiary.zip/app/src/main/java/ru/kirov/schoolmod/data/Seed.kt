package ru.kirov.schoolmod.data

/** Расписание по умолчанию («оригинал») и первоначальные справочники. */
object Seed {

    private class L(
        val day: Int,
        val number: Int,
        val subject: String,
        val teacher: String?,
        val room: String?
    )

    private val defaultLessons = listOf(
        L(1, 1, "Математика", "Иванова И.И.", "101"),
        L(1, 2, "Русский язык", "Петрова А.А.", "205"),
        L(1, 3, "Физкультура", "Сидоров П.П.", "Спортзал"),
        L(2, 1, "Русский язык", "Петрова А.А.", "205"),
        L(2, 2, "Математика", "Иванова И.И.", "101"),
        L(2, 3, "Физика", null, "301"),
        L(3, 1, "Физкультура", "Сидоров П.П.", "Спортзал"),
        L(3, 2, "Математика", "Иванова И.И.", "101"),
        L(3, 3, "Химия", null, "302"),
        L(4, 1, "Физика", null, "301"),
        L(4, 2, "Русский язык", "Петрова А.А.", "205"),
        L(4, 3, "Математика", "Иванова И.И.", "101"),
        L(5, 1, "Химия", null, "302"),
        L(5, 2, "Физкультура", "Сидоров П.П.", "Спортзал"),
        L(5, 3, "Русский язык", "Петрова А.А.", "205")
    )

    /** Находит сущность по имени или создаёт новую, выдавая id из счётчика. */
    private class Builder(var d: DiaryData) {
        fun newId(): Long {
            val id = d.nextId
            d = d.copy(nextId = id + 1)
            return id
        }

        fun subject(name: String): Long {
            d.subjects.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { return it.id }
            val id = newId()
            d = d.copy(subjects = d.subjects + Subject(id, name))
            return id
        }

        fun teacher(name: String): Long {
            d.teachers.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { return it.id }
            val id = newId()
            d = d.copy(teachers = d.teachers + Teacher(id, name))
            return id
        }

        fun room(name: String): Long {
            d.rooms.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { return it.id }
            val id = newId()
            d = d.copy(rooms = d.rooms + Room(id, name))
            return id
        }
    }

    private fun applyLessons(b: Builder) {
        val lessons = ArrayList<Lesson>()
        for (l in defaultLessons) {
            val subjectId = b.subject(l.subject)
            val teacherId = l.teacher?.let { b.teacher(it) }
            val roomId = l.room?.let { b.room(it) }
            lessons.add(
                Lesson(
                    id = b.newId(),
                    day = l.day,
                    number = l.number,
                    subjectId = subjectId,
                    teacherId = teacherId,
                    roomId = roomId,
                    start = Bells.start(l.number),
                    end = Bells.end(l.number)
                )
            )
        }
        b.d = b.d.copy(lessons = lessons)
    }

    fun initial(): DiaryData {
        val b = Builder(DiaryData())
        applyLessons(b)
        return b.d
    }

    /** Заменяет все уроки на исходное расписание; предметы, учителя и оценки остаются. */
    fun resetSchedule(base: DiaryData): DiaryData {
        val b = Builder(base)
        applyLessons(b)
        return b.d
    }
}
