package ru.kirov.schoolmod

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {
    private val monthNames = listOf("Январь","Февраль","Март","Апрель","Май","Июнь","Июль",
        "Август","Сентябрь","Октябрь","Ноябрь","Декабрь")
    private val dayNames = listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС")

    private var weekOffset = 0
    private var selectedDay = 0
    private var data = ScheduleStore.defaults()

    private lateinit var monthLabel: TextView
    private lateinit var strip: LinearLayout
    private lateinit var lessons: LinearLayout

    // Секретный вход: 7 быстрых нажатий на заголовок (интервал между нажатиями < 800 мс)
    private var taps = 0
    private var lastTap = 0L

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val cal = Calendar.getInstance()
        selectedDay = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val title = header("Образование Кировской области")
        title.setOnClickListener {
            val now = SystemClock.elapsedRealtime()
            taps = if (now - lastTap < 800) taps + 1 else 1
            lastTap = now
            if (taps >= 7) { taps = 0; startActivity(Intent(this, EditorActivity::class.java)) }
        }
        root.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        monthLabel = TextView(this).apply {
            textSize = 24f; setTextColor(0xFF222222.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(12))
        }
        root.addView(monthLabel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val navRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), dp(8)) }
        navRow.addView(arrow("←") { weekOffset--; render() })
        strip = LinearLayout(this).apply { weightSum = 7f }
        navRow.addView(strip, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        navRow.addView(arrow("→") { weekOffset++; render() })
        root.addView(navRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        lessons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16)) }
        root.addView(ScrollView(this).apply { addView(lessons) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Нижняя навигация (визуальная копия оригинала)
        val bottom = LinearLayout(this).apply { setBackgroundColor(Color.WHITE); weightSum = 4f }
        listOf("Основное","Дневник","Успеваемость","Профиль").forEachIndexed { i, t ->
            bottom.addView(TextView(this).apply {
                text = t; gravity = Gravity.CENTER; textSize = 12f
                setPadding(0, dp(14), 0, dp(14))
                setTextColor(if (i == 1) C.BLUE else 0xFF444444.toInt())
                if (i == 1) setTypeface(typeface, Typeface.BOLD)
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); data = ScheduleStore.load(this); render() }

    private fun arrow(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 24f; gravity = Gravity.CENTER; setTextColor(C.BLUE)
        background = roundBg(C.LIGHT, 40)
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(2), 0, dp(2), 0) }
        setOnClickListener { onClick() }
    }

    private fun render() {
        val monday = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            add(Calendar.WEEK_OF_YEAR, weekOffset)
        }
        monthLabel.text = "${monthNames[monday.get(Calendar.MONTH)]} ${monday.get(Calendar.YEAR)}"

        strip.removeAllViews()
        for (i in 0 until 7) {
            val c = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
                background = if (i == selectedDay) roundBg(Color.WHITE, 4, C.BLUE) else roundBg(Color.WHITE, 4)
                setOnClickListener { selectedDay = i; render() }
            }
            col.addView(TextView(this).apply { text = dayNames[i]; textSize = 12f
                setTextColor(if (i == 6) C.RED else Color.BLACK) })
            col.addView(TextView(this).apply { text = c.get(Calendar.DAY_OF_MONTH).toString(); textSize = 18f
                setTypeface(typeface, Typeface.BOLD); setTextColor(if (i == 6) C.RED else Color.BLACK) })
            strip.addView(col, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(1), 0, dp(1), 0) })
        }

        lessons.removeAllViews()
        val day = data[selectedDay]
        if (day.isEmpty()) {
            lessons.addView(TextView(this).apply { text = "Нет уроков"; gravity = Gravity.CENTER
                textSize = 16f; setTextColor(0xFF777777.toInt()); setPadding(0, dp(40), 0, 0) })
        }
        day.forEachIndexed { idx, l ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = roundBg(Color.WHITE, 12)
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            card.addView(TextView(this).apply { text = "${idx + 1}. ${l.subject}"; textSize = 18f
                setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD) })
            card.addView(TextView(this).apply { text = "${l.start} – ${l.end}  •  каб. ${l.room}"
                textSize = 14f; setTextColor(C.BLUE) })
            card.addView(TextView(this).apply { text = l.teacher; textSize = 14f; setTextColor(0xFF555555.toInt()) })
            lessons.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, 0, 0, dp(10)) })
        }
    }
}
